export class Emp {
    empId: number;
    fisrtName: string;
    lastName: string;
}