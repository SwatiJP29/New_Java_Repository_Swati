SimpleShoppingStore
===================

This is a simple shopping cart application written using JSP and Servlets. 

This serves as a project to learn the Java Web Development practices.

Technologies covered include JSP,Servlets,JDBC API,Java Mail API.

Another implementation using JSP and Servlets:

https://github.com/SaiUpadhyayula/OnlineKart

A similar shopping cart using Spring Framework

https://github.com/SaiUpadhyayula/SpringShoppingStore

